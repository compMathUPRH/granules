# Granules
![granules-logo](granules_logo.png)  
Granules is a Pandas DataFrame-based Python package to manage and analyze Molecular Dynamics simulations. 
Granules is still under development.

#### Dependencies
* Numpy
* Pandas
* Scipy

